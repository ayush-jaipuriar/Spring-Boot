package com.ayush.initializerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InitializerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
